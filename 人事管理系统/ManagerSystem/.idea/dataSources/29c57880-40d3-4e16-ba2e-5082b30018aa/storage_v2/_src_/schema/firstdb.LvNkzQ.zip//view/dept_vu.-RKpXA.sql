create view dept_vu as
  select `d`.`DNAME`    AS `DNAME`,
         min(`e`.`SAL`) AS `MIN(E.SAL)`,
         max(`e`.`SAL`) AS `MAX(E.SAL)`,
         avg(`e`.`SAL`) AS `AVG(E.SAL)`
  from `firstdb`.`emp` `e`
         join `firstdb`.`dept` `d`
  where (`e`.`DEPTNO` = `d`.`DEPTNO`)
  group by `d`.`DNAME`;

