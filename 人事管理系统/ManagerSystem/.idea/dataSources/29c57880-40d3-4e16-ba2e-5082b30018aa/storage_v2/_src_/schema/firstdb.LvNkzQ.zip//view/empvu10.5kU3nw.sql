create view empvu10 as
  select `firstdb`.`emp`.`EMPNO` AS `EMPNO`, `firstdb`.`emp`.`ENAME` AS `ENAME`, `firstdb`.`emp`.`JOB` AS `JOB`
  from `firstdb`.`emp`
  where (`firstdb`.`emp`.`DEPTNO` = 10);

