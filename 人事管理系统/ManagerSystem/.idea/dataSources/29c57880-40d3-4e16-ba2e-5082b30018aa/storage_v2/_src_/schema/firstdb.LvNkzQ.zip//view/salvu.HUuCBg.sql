create view salvu as
  select `firstdb`.`emp`.`EMPNO` AS `EMPNO`, `firstdb`.`emp`.`ENAME` AS `ENAME`, `firstdb`.`emp`.`SAL` AS `SAL`
  from `firstdb`.`emp`
  where ((`firstdb`.`emp`.`SAL` between 2000 and 5000) and (`firstdb`.`emp`.`ENAME` like '%A%'));

